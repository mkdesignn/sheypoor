<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Formula extends Model
{
    use SoftDeletes;
    public $fillable = ["code", "created_date", "concentrate_type", "protein", 'product_name',
        "pure_lactation_energy", "metabolism_energy", "dry_matter", "calcium", "phosphorus"];

    /**
     * @return \Illuminate\Database\Eloquent\Relations\HasMany
     */
    public function items(){
        return $this->hasMany(FormulaItem::class, 'formula_id', 'id');
    }

    /**
     * @return \Illuminate\Database\Eloquent\Relations\HasOne
     */
    public function concentrate(){
        return $this->hasOne(Meta::class, 'id', 'concentrate_type');
    }

    /**
     * delete all related records
     */
    public static function boot(){
        parent::boot();

        // remove all the attendances for the current schedule
        static::deleting(function($formula){
            if( $formula->items != null ){
                foreach($formula->items as $item){
                    $item->delete();
                }
            }
        });
    }

}
