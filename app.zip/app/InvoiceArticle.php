<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class InvoiceArticle extends Model
{

    protected $table = "invoice_articles";

    /**
     * @var array
     */
    protected $appends = ["finish_price"];


    protected $fillable = ["invoice_id", "product_id", "formula_id", "total_bag", "total_weight",
        "price", "discount_price_percent", "profit_percent", "time", "breath_time"
        , "total_price", "checkout_date"];

    public function formula(){
        return $this->hasOne(Formula::class, 'id', 'formula_id');
    }

    public function invoice(){
        return $this->hasOne(InvoiceHeader::class, 'id', 'invoice_id');
    }

    public function product(){
        return $this->hasOne(Meta::class, 'id', 'product_id');
    }

    public function getFinishPriceAttribute(){

        // profit
        if ($this->discount_price_percent == 0 || $this->discount_price_percent === ""){
            $profit_price = ceil( ( ( ( ($this->breath_time - $this->time) / 30 ) * $this->profit_percent ) * $this->price) / 100 );
            return $this->price + $profit_price;
        }

        // discount
        else {
            $discounted_price = ceil( ($this->price * $this->discount_price_percent) / 100);
            return $this->price - $discounted_price;
        }
    }
}
