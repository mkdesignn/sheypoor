<?php

namespace App\Http\Controllers;

use App\Agency;
use Illuminate\Http\Request;

class AgentController extends Controller
{
    /**
     * @var Agency
     */
    private $agency;

    /**
     * @param Request $request
     * @param Agency $agency
     */
    function __construct(Request $request, Agency $agency){
        parent::__construct($request);
        $this->agency = $agency;
    }

    function getIndex(){

        if( $this->request->ajax() )
        {
            return $this->paginate($this->agency);
        } else
            return View("admin.agency.index");
    }

    function getCreate(){

        return View("admin.agency.create");
    }

    /**
     * @return \Illuminate\Http\RedirectResponse
     */
    function postStore(){

        $inputs = $this->request->except(["_token"]);
        $this->agency->create($inputs);
        return redirect()->back()->with(["msg"=>"آژانس مورد نظر با موفقیت ثبت شد ."]);
    }

    function getEdit($agent_id){

        $agency = $this->agency->whereId($agent_id)->first();
        return view("admin.agency.edit", compact("agency"));
    }

    function postUpdate($agent_id){
        $inputs = $this->request->except(["_token"]);
        $this->agency->whereId($agent_id)->update($inputs);
        return redirect()->back()->with(["msg"=>"آزانس مورد نظر با موفقیت ویرایش شد ."]);
    }

    function getDelete($agent_id){

        $this->agency->whereId($agent_id)->delete();
        return 'true';
    }
}
