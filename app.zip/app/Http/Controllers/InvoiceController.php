<?php

namespace App\Http\Controllers;

use App\Agency;
use App\Formula;
use App\InvoiceArticle;
use App\InvoiceHeader;
use App\Meta;
use Illuminate\Http\Request;

class InvoiceController extends Controller
{
    /**
     * @var Factor
     */
    private $factor;
    /**
     * @var InvoiceArticle
     */
    private $invoiceArticle;
    /**
     * @var Meta
     */
    private $meta;
    /**
     * @var Formula
     */
    private $formula;
    /**
     * @var Agency
     */
    private $agency;
    /**
     * @var InvoiceHeader
     */
    private $invoiceHeader;

    /**
     * @param Request $request
     * @param InvoiceArticle $invoiceArticle
     * @param Meta $meta
     * @param Formula $formula
     * @param Agency $agency
     * @param InvoiceHeader $invoiceHeader
     * @internal param Factor $factor
     */
    function __construct(Request $request, InvoiceArticle $invoiceArticle, Meta $meta,
                         Formula $formula, Agency $agency, InvoiceHeader $invoiceHeader){
        parent::__construct($request);
        $this->invoiceArticle = $invoiceArticle;
        $this->meta = $meta;
        $this->formula = $formula;
        $this->agency = $agency;
        $this->invoiceHeader = $invoiceHeader;
    }


    /**
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\View\View|string
     */
    function getIndex(){

        if( $this->request->ajax() ){
            return $this->paginate($this->invoiceHeader
                ->with(['agency'=> function($query){
                    $query->select("agencies.zone", "agencies.id");
                }, 'singers']));
        } else {
            return View("admin.invoice.header.index");
        }
    }


    /**
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\View\View
     */
    function getCreate(){

        $buyer_type = $this->meta->where("meta_key", "buyer_type")->get()->pluck("meta_value", "id");
        $signer = $this->meta->where("meta_key", "signer")->get()->pluck("meta_value", "id");

        $zone = $this->agency->get()->pluck("zone", "id");

        return View("admin.invoice.header.create",  compact("buyer_type", "signer", "zone"));
    }

    /**
     * @return \Illuminate\Http\RedirectResponse
     */
    function postStore(){

        // create the invoice header
        $all_inputs = $this->request->except(["_token"]);
        $this->invoiceHeader->create($all_inputs);

        return redirect()->action("InvoiceController@getIndex");
    }

    function postStoreArticles(){

        // create the invoice header
        $all_inputs = $this->request->except(["_token"]);
        $created_invoice = $this->invoiceArticle->create($all_inputs);

        return $this->invoiceArticle->where("id", $created_invoice->id)
            ->with(['product', 'formula'=> function($query){
                $query->select("formulas.concentrate_type", 'formulas.id');
            }])->first();

    }


    /**
     * @param $invoice_id
     */
    function postUpdate($invoice_id){

    }

    function postUpdateArticles($article_id){

    }

    /**
     * @param $invoice_id
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\View\View|string
     */
    function getArticles($invoice_id){

        if( !$this->request->ajax() ){
            $formula_code = $this->formula->get()->pluck("code", "id");
            $products = $this->meta->where("meta_key", "product")->get()->pluck("meta_value", "id");
            return View("admin.invoice.articles.show", compact("products", "formula_code", "invoice_id"));
        }
        else{
            $invoice_articles = $this->invoiceArticle->where("invoice_id", $invoice_id)
                ->with(['product', 'formula'=> function($query){
                    $query->select("formulas.concentrate_type", 'formulas.id');
                }, 'formula.concentrate']);
            return $this->paginate($invoice_articles);

        }

    }

    function getPrint($invoice_id, $print_type){

        $invoice = $this->invoiceHeader->whereId($invoice_id)->first();
        $articles = $this->invoiceArticle->whereInvoiceId($invoice_id)->get();

        if( $print_type === 'invoice'){
            return View('admin.print.invoice', compact("articles", "invoice"));
        } elseif( $print_type === 'analyze' ){
            return View('admin.print.analyze', compact("articles", "invoice"));
        } elseif( $print_type === 'ingredients' ){
            return View('admin.print.ingredients', compact("articles", 'invoice'));
        } elseif( $print_type === 'agencies' ){
            return View('admin.print.agency', compact("articles", 'invoice'));
        }

    }

    /**
     * @param $article_id
     * @return mixed
     */
    function getShowArticle($article_id){

        return $this->invoiceArticle->whereId($article_id)->first();
    }

    /**
     * @param $invoice_id
     * @return string
     */
    function getDelete($invoice_id){
        $this->invoiceHeader->whereId($invoice_id)->delete();
        return response('true', 200);
    }

    function getDeleteArticle($article_id){

        $this->invoiceArticle->whereId($article_id)->delete();
        return response('true', 200);
    }
}
