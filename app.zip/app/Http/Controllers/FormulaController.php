<?php

namespace App\Http\Controllers;

use App\Formula;
use App\FormulaItem;
use App\Meta;
use Illuminate\Http\Request;

class FormulaController extends Controller
{
    /**
     * @var Formula
     */
    private $formula;
    /**
     * @var Meta
     */
    private $meta;
    /**
     * @var FormulaItem
     */
    private $formulaItem;

    /**
     * @param Request $request
     * @param Formula $formula
     * @param FormulaItem $formulaItem
     * @param Meta $meta
     */
    function __construct(Request $request, Formula $formula, FormulaItem $formulaItem, Meta $meta){

        parent::__construct($request);

        $this->request = $request;
        $this->formula = $formula;
        $this->meta = $meta;
        $this->formulaItem = $formulaItem;
    }


    /**
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\View\View|string
     */
    public function getIndex(){

        if ($this->request->ajax()){
            return $this->paginate($this->formula);
        } else
            return view("admin.formula.index");
    }

    /**
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\View\View
     */
    public function getCreate(){
        $concentrate_type = $this->meta->where("meta_key", "product")->get()->pluck("meta_value", "id");
        return View("admin.formula.create", compact("concentrate_type"));
    }

    public function getCreateItem($formula_id){

        return View("admin.formula.item.create", compact("formula_id"));
    }

    /**
     * @return \Illuminate\Http\RedirectResponse
     */
    public function postStore(){

        $inputs = $this->request->except(["_token"]);
        $this->formula->create($inputs);
        return redirect()->back()->with(["msg"=>"فرمول مورد نظر با موفقیت ذخیره شد ."]);
    }

    /**
     * @param $formula_id
     * @return \Illuminate\Http\RedirectResponse
     */
    public function postUpdate($formula_id){

        $inputs = $this->request->except(["_token"]);
        $this->formula->whereId($formula_id)->update($inputs);
        return redirect()->back()->with(["msg"=>"فرمول مورد نظر با موفقیت ذخیره شد ."]);

    }

    /**
     * @param $formula_id
     * @return string
     */
    public function getDelete($formula_id){

        $this->formula->whereId($formula_id)->delete();
        return "true";
    }

    /**
     * @param $formula_id
     * @return mixed
     */
    public function getItems($formula_id){

        if( !$this->request->ajax() )
        {
            $formula = $this->formula->whereId($formula_id)->first();
            return View("admin.formula.item.index", compact("formula"));
        }
        else{
            return $this->paginate($this->formula->whereId($formula_id)->first()->items());
        }
    }

    /**
     * @param $item_id
     * @return string
     */
    public function postUpdateItem($item_id){

        $items = $this->request->except(["_token"]);
        $this->formulaItem->whereId($item_id)->update([$items]);
        return 'true';
    }

    /**
     * @param $formula_id
     * @return string
     */
    public function postStoreItem($formula_id){

        $items = $this->request->except(["_token"]);
        $items["formula_id"] = $formula_id;

        $this->formulaItem->create($items);
        return redirect()->back()->with(["msg"=>"فرمول مورد نظر با موفقیت ثبت شد ."]);
    }

    /**
     * @param $item_id
     * @return string
     */
    public function getDeleteItem($item_id){

        $this->formulaItem->whereId($item_id)->delete();
        return "true";
    }

}
