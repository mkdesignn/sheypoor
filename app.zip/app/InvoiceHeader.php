<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class InvoiceHeader extends Model
{
    protected $table = "invoice_header";

    protected $fillable = ["buyer", "car_number", "driver", "issue_date", "buyer_type", "attachment_id",
        "zone", "signer", "comment"];

    protected $appends = ["price"];

    public function agency(){
        return $this->hasOne(Agency::class, 'id', 'zone');
    }

    public function singers(){
        return $this->hasOne(Meta::class, 'id', 'signer');
    }

    public function articles(){
        return $this->hasMany(InvoiceArticle::class, 'invoice_id', 'id');
    }

    public function getPriceAttribute(){
        $price = 0;
        $this->articles->each(function($row) use (&$price){
            $price += $row->total_weight * $row->price;
        });

        return $price;
    }
}
