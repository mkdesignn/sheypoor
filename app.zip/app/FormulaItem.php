<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class FormulaItem extends Model
{

    use SoftDeletes;
    protected $dates = ['deleted_at'];


    protected $fillable = ["formula_id", "item_name", "item_percent"];
}
