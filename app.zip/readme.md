## Laravel Theme

it's a laravel theme which you can download and enjoy working with it, doe not have any front end
pages, but it contains the auth page and the admin page is setup for you, it uses vue.js packages
so you can define your vue.js packages very easily and enjoy using them.

### installation

## install through composer

composer create-project mkdesignn/laravel-theme