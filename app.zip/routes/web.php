<?php

Route::group(["middleware"=>"auth"], function(){

    Route::group(["middleware"=>"user:admin"], function(){

        Route::group(["prefix"=>"panel"], function(){

            // all routes goes here
            Route::get("log", "LogController@getIndex")->name("log");

            // factor routes
            Route::get("invoice", "InvoiceController@getIndex")->name("invoice.index");
            Route::get("invoice/create", "InvoiceController@getCreate")->name("invoice.create");
            Route::post("invoice/store", "InvoiceController@postStore")->name("invoice.store");
            Route::post("invoice/store-articles", "InvoiceController@postStoreArticles")->name("invoice.store-articles");
            Route::get("invoice/delete/{id}", "InvoiceController@getDelete")->name("invoice.delete");
            Route::get("invoice/articles/{id}", "InvoiceController@getArticles")->name("invoice.articles");
            Route::get("invoice/delete-article/{id}", "InvoiceController@getDeleteArticle")->name("invoice.delete-article");
            Route::get("invoice/print/{id}/{invoicetype}", "InvoiceController@getPrint")->name("invoice.print");

            // formula route
            Route::get("formula", "FormulaController@getIndex")->name("formula.index");
            Route::get("formula/create", "FormulaController@getCreate")->name("formula.create");
            Route::post("formula/store", "FormulaController@postStore")->name("formula.store");
            Route::get("formula/edit/{id}", "FormulaController@getEdit")->name("formula.edit");
            Route::get("formula/delete/{id}", "FormulaController@getDelete")->name("formula.delete");
            Route::get("formula/items/{id}", "FormulaController@getItems")->name("formula.items");
            Route::get("formula/item/edit/{id}", "FormulaController@getItem")->name("formula.item.edit");
            Route::get("formula/item/delete/{id}", "FormulaController@getDeleteItem")->name("formula.item.delete");
            Route::post("formula/item/store/{id}", "FormulaController@postStoreItem")->name("formula.item.store");
            Route::post("formula/item/update", "FormulaController@postUpdateItem")->name("formula.item.update");
            Route::get("formula/item/create/{id}", "FormulaController@getCreateItem")->name("formula.item.create");

            // agent routes
            Route::get("agent", "AgentController@getIndex")->name("agent.index");
            Route::get("agent/create", "AgentController@getcreate")->name("agent.create");
            Route::post("agent/store", "AgentController@postStore")->name("agent.store");
            Route::post("agent/update", "AgentController@postUpdate")->name("agent.update");
            Route::get("agent/delete/{id}", "AgentController@getDelete")->name("agent.delete");



            // user routes
            Route::get("user", "UserController@getIndex")->name("user.index");
            Route::get("user/create", "UserController@getCreate")->name("user.create");
            Route::get("user/edit/{id}", "UserController@getEdit")->name("user.edit");
            Route::get("user/delete/{id}", "UserController@getDelete")->name("user.delete");
            Route::post("user/store", "UserController@postStore")->name("user.store");

            Route::get("config", "ConfigController@getIndex")->name("config.index");
            Route::post("config", "ConfigController@postStore")->name("config.store");
        });

        Route::get("panel", "PanelController@getIndex")->name("panel.index");
    });
});

Auth::routes();

