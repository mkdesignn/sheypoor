<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateFormulasTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('formulas', function (Blueprint $table) {
            $table->increments('id');
            $table->string('code');
            $table->string('created_date');
            $table->string('concentrate_type');
            $table->string('Protein');
            $table->string('Pure_lactation_energy');
            $table->string('Metabolism_energy');
            $table->string('dry_matter');
            $table->string('Calcium');
            $table->string('Phosphorus');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::drop('formulas');
    }
}
