<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateInvoiceHeaderTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('invoice_header', function (Blueprint $table) {
            $table->increments('id');
            $table->string('buyer');
            $table->string('car_number');
            $table->string('driver');
            $table->string('issue_date');
            $table->enum('buyer_type', ["??????? ????", "??????? ??? ????", "??????"]);
            $table->string('attachment_id');
            $table->string('zone');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::drop('invoice_header');
    }
}
