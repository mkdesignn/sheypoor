<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateInvoiceArticlesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('invoice_articles', function (Blueprint $table) {
            $table->increments('id');
            $table->integer('product_id');
            $table->integer('formula_id');
            $table->string('total');
            $table->string('total_weight');
            $table->string('price');
            $table->string('discount_price_percent');
            $table->string('profit_percent');
            $table->string('time');
            $table->string('breath_time');
            $table->string('fixed_price');
            $table->string('total_price');
            $table->string('checkout_date');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::drop('invoice_article');
    }
}
