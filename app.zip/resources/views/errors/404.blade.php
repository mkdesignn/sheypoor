@extends("master")
@section("header")
    <title>صفحه مورد نظر یافت نشد</title>
@endsection
@section("content")
    <main class="container content-wrap">
        <!-- col-lg-9 col-md-9 col-sm-8 -->
        <section class="blog-posts">
           <h3 class="center"> صفحه مورد نظر یافت نشد  </h3>
        </section>
    </main>
@endsection
