<html>
    <head>
        <title></title>
    </head>
    <body>
        <div>
            {{ $respond }}
        </div>
    </body>
</html>
