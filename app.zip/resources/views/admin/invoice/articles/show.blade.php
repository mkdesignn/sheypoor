@extends("admin.master")
@section("content")
    <div class="wrapper" id="wrapper">
        {{ !empty(Session::get('msg'))? message(Session::get('msg')):"" }}
        {{errors($errors)}}
        {!! Form::open(["url"=>url()->action("InvoiceController@postStoreArticles")]) !!}
        <p>
            ایجاد اقلام فاکتور
        </p>
        <hr style="border:1px solid rgba(42,42,42,.1)"/>
        <div class="row"  style="overflow:auto;margin-bottom:20px;">
            <notification :notify_danger="notify_danger"  :notify_success="notify_success"
                          :notify_alarm="notify_alarm" :notify_warning="notify_warning" :notify_text="notify_text"></notification>
            <div class="col-md-12 col-lg-12 col-sm-12">
                <h4>
                    اطلاعات کالا
                </h4>
            </div>
            <div class="col-md-3 pull-right right">
                <div class="form-group">
                    <label for="inputEmail">نام کالا</label>
                    <div class="input-group">
                        {!!Form::select("product_id", $products, null, array("class"=>'form-control autosizeme',
                         "v-model"=>"product_id", "v-bind:class"=>"{'border-danger': errors.has('product_id')}", "v-validate"=>"'required'", "style"=>"height:40px;"))!!}
                        <span class="input-group-addon icomoon-uniE04B" style="font-size:large;"></span>
                    </div>
                </div>
            </div>
            <div class="col-md-3 pull-right right">
                <div class="form-group">
                    <label for="inputEmail">تعداد کیسه</label>
                    <div class="input-group">
                        {!!Form::text("total_bag", null, array("class"=>'form-control autosizeme', "v-validate"=>"'required|min_value:1|decimal'",
                         "v-model"=>"bag", "v-bind:class"=>"{'border-danger': errors.has('total_bag')}", "tabindex"=>"0", "style"=>"height:40px;", "placeholder"=>"..."))!!}
                        <span class="input-group-addon icomoon-uniE04B" style="font-size:large;"></span>
                    </div>
                </div>
            </div>
            <div class="col-md-3 pull-right right">
                <div class="form-group">
                    <label for="inputEmail">وزن کل</label>
                    <div class="input-group">
                        {!!Form::text("total_weight", null, array("class"=>'form-control autosizeme', "v-validate"=>"'required|min_value:1|decimal'"
                        , "v-model"=>"total_weight", "v-bind:class"=>"{'border-danger': errors.has('total_weight')}", "style"=>"height:40px;", "placeholder"=>"..."))!!}
                        <span class="input-group-addon icomoon-uniE04B" style="font-size:large;"></span>
                    </div>
                </div>
            </div>
            <div class="col-md-3 pull-right right">
                <div class="form-group">
                    <label for="inputEmail">قیمت واحد</label>
                    <div class="input-group">
                        <currency v-on:pass-data="priceInput" :attr="{name: 'price', style: 'height:40px;'}"></currency>
                        {{--{!!Form::text("price", null, array("class"=>'form-control autosizeme', "v-model"=>"price", "style"=>"height:40px;", "placeholder"=>"..."))!!}--}}
                        <span class="input-group-addon icomoon-uniE04B" style="font-size:large;"></span>
                    </div>
                </div>
            </div>
            <div class="col-md-3 pull-right right">
                <div class="form-group">
                    <label for="inputEmail">کد فرمول</label>
                    <div class="input-group">
                        {!!Form::select("formula_id", $formula_code, null, array("class"=>'form-control autosizeme', 'v-model'=>'formula_id',
                         "v-bind:class"=>"{'border-danger': errors.has('formula_id')}", "v-validate"=>"'required'", "style"=>"height:40px;"))!!}
                        <span class="input-group-addon icomoon-uniE04B" style="font-size:large;"></span>
                    </div>
                </div>
            </div>
            <div class="col-md-3 pull-right right">
                <div class="form-group">
                    <label for="inputEmail">مبلغ کل</label>
                    <div class="input-group">
                        {!!Form::text("total_price",  null, array("class"=>'form-control autosizeme', 'readonly'=>"readonly", 'v-model'=>"total_price", "style"=>"height:40px;"))!!}
                        <span class="input-group-addon icomoon-uniE04B" style="font-size:large;"></span>
                    </div>
                </div>
            </div>
        </div>
        <div class="row" style="overflow:auto;margin-bottom:20px;">
            <div class="col-md-12 col-lg-12 col-sm-12">
                <h4>
                    نوع خرید
                </h4>
            </div>
            <div class="col-md-6 col-lg-6 col-md-6">
                <div class="row">
                    <div class="col-md-12 pull-right right">
                        <label for="buying_type_installment">
                            قسطی
                            {!!Form::radio("buying_type", "installment", null, array("class"=>'autosizeme', 'v-model'=>"buying_type", "id"=>"buying_type_installment"))!!}
                        </label>
                    </div>
                    <div class="col-md-6 pull-right right">
                        <div class="form-group">
                            <label for="inputEmail">تنفس فروش</label>
                            <div class="input-group">
                                {!!Form::text("time", null, array("class"=>'form-control autosizeme', 'v-model'=>"time", ":disabled"=>"buying_type !== 'installment'", "style"=>"height:40px;"))!!}
                                <span class="input-group-addon icomoon-uniE04B" style="font-size:large;"></span>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6 pull-right right">
                        <div class="form-group">
                            <label for="inputEmail">مدت دار</label>
                            <div class="input-group">
                                {!!Form::text("breath_time", null, array("class"=>'form-control autosizeme', 'v-model'=>"breath_time", ":disabled"=>"buying_type !== 'installment'", "style"=>"height:40px;"))!!}
                                <span class="input-group-addon icomoon-uniE04B" style="font-size:large;"></span>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-12 pull-right right">
                        <div class="form-group">
                            <label for="inputEmail">درصد سود</label>
                            <div class="input-group">
                                {!!Form::text("profit_percent", null, array("class"=>'form-control autosizeme', 'v-model'=>"profit_percent", ":disabled"=>"buying_type !== 'installment'", "style"=>"height:40px;"))!!}
                                <span class="input-group-addon icomoon-uniE04B" style="font-size:large;"></span>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-12 pull-right right">
                        <div class="form-group">
                            <label for="inputEmail">مبلغ با سود</label>
                            <div class="input-group">
                                {!!Form::text("price_profit", null, array("class"=>'form-control autosizeme', 'v-model'=>"price_profit", ":disabled"=>"buying_type !== 'installment'", "style"=>"height:40px;"))!!}
                                <span class="input-group-addon icomoon-uniE04B" style="font-size:large;"></span>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-12 pull-right right">
                        <label for="inputEmail">
                            پرینت نماینده ها
                            {!!Form::checkbox("agencies", 1, null, array('v-model'=>"agencies"))!!}
                        </label>
                    </div>
                </div>
            </div>
            <div class="col-md-6 col-lg-6 col-sm-6">
                <div class="row">
                    <div class="col-md-12 pull-right right">
                        <label for="buying_type_cash">نقدی
                            {!! Form::radio("buying_type", "cash", null, array("class"=>'autosizeme', 'v-model'=>'buying_type', "id"=>"buying_type_cash")) !!}
                        </label>
                    </div>
                    <div class="col-md-12 pull-right right">
                        <div class="form-group">
                            <label for="inputEmail">درصد تخفیف</label>
                            <div class="input-group">
                                {!!Form::text("discount_price_percent", null, array("class"=>'form-control autosizeme', "maxlength"=>"2", 'v-model'=>"discount_price_percent", ":disabled"=>"buying_type !== 'cash'", "style"=>"height:40px;"))!!}
                                <span class="input-group-addon icomoon-uniE04B" style="font-size:large;"></span>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-12 pull-right right">
                        <div class="form-group">
                            <label for="inputEmail">مبلغ با تخفیف</label>
                            <div class="input-group">
                                {!!Form::text("discount_price", null, array("class"=>'form-control autosizeme', "v-model"=>"discount_price", "readonly"=>"readonly", ":disabled"=>"buying_type !== 'cash'", "style"=>"height:40px;"))!!}
                                <span class="input-group-addon icomoon-uniE04B" style="font-size:large;"></span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <hr>
        <div class="row">
            <div class="col-md-12 col-sm-12 col-lg-12">
                <input type="button" v-on:click="registerAnArticle($event, '{{action("InvoiceController@postStoreArticles")}}')" value="ذخیره" class="btn btn-primary"/>
            </div>
        </div>
        {!! Form::close() !!}
        <hr/>
        <datagridview :head="head" :created_record="created_record" :url="url"></datagridview>
        <input type="button" v-on:click="preparePrintPages('{{action('InvoiceController@getPrint', [$invoice_id, 'invoice'])}}')" class="btn btn-primary" value="فاکتور"/>
        <input type="button" v-on:click="preparePrintPages('{{action('InvoiceController@getPrint', [$invoice_id, 'ingredients'])}}')" class="btn btn-primary" value="ترکیبات"/>
        <input type="button" v-on:click="preparePrintPages('{{action('InvoiceController@getPrint', [$invoice_id, 'analyze'])}}')" class="btn btn-primary" value="آنالیز"/>
        <input type="button" v-if="agencies" v-on:click="preparePrintPages('{{action('InvoiceController@getPrint', [$invoice_id, 'agencies'])}}')" class="btn btn-primary" value="پرینت نماینده ها"/>
    </div>
@endsection

@section("script")

    <script>

        var data = {
            created_record: '',
            invoice_id: "{{$invoice_id}}",
            step: 0,
            bag: 0,
            total_weight: 0,
            price: 0,
            discount_percent: 0,
            discount_price: 0,
            price_profit: 0,
            discount_price_percent: 0,
            product_id: '',
            buying_type: 'cash',
            breath_time: '',
            profit_percent: '',
            time: '',
            total_price: '',
            fill_data: '',
            formula_id: '',
            agencies: '',
            url: "{{action('InvoiceController@getArticles', $invoice_id)}}",
            head: {
                fake_id  : "#",
                'product.meta_value':    'نام کالا',
                'formula.concentrate.meta_value':  'کد فرمول',
                total_bag:   'تعداد کیسه',
                total_weight:    'وزن کل',
                price:     'قیمت واحد',
                discount_price_percent:  'درصد تخفیف',
                profit_percent:  'درصد سود',
                time:  'مدت دار',
                breath_time:  'تنفس فروش',
                total_price:  'مبلغ کل'
            },
            buttons:{
                edit:{
                    label: "ویرایش",
                    btnClass: "btn btn-primary",
                    url: "{{action('InvoiceController@getIndex')}}/show-article/{id}",
                    action: 'ajax-request',
                    style: "font-size:smaller;margin-left:10px;",
                    fill_data: "fill_data"
                },
                removeInvoice:{
                    label: 'حذف فاکتور',
                    btnClass: "btn btn-danger",
                    url: "{{action('InvoiceController@getIndex')}}/delete-article/{id}",
                    action: 'confirm',
                    confirm_text: 'از حذف این رکورد مطمئن هستید ؟',
                    style: "font-size:smaller;margin-left:10px;"
                }
            },
            notify_danger:false,
            notify_success:false,
            notify_alarm:false,
            notify_warning: false,
            notify_text:""
        }

    </script>

    {!! Html::script("invoice-create.js") !!}
@endsection