@extends("admin.master")
@section("content")
<div class="wrapper" id="wrapper">
    {{ !empty(Session::get('msg'))? message(Session::get('msg')):"" }}
    {{errors($errors)}}
    {!! Form::open(["url"=>url()->action("InvoiceController@postStore")]) !!}
    <p>
        ایجاد فاکتور
    </p>
    <hr style="border:1px solid rgba(42,42,42,.1)"/>
    <div class="row" style="overflow:auto;margin-bottom:20px;">
        <div class="col-md-12 col-lg-12 col-sm-12">
            <h4>
                اطلاعات اولیه
            </h4>
        </div>
        <div class="col-md-3 pull-right right">
            <div class="form-group">
                <label for="inputEmail">خریدار</label>
                <div class="input-group">
                    {!!Form::text("buyer", null, array("class"=>'form-control autosizeme', "style"=>"height:40px;", "placeholder"=>"..."))!!}
                    <span class="input-group-addon icomoon-uniE04B" style="font-size:large;"></span>
                </div>
            </div>
        </div>
        <div class="col-md-3 pull-right right">
            <div class="form-group">
                <label for="inputEmail">شماره ماشین</label>
                <div class="input-group">
                    {!!Form::text("car_number", null, array("class"=>'form-control autosizeme', "tabindex"=>"0", "style"=>"height:40px;", "placeholder"=>"..."))!!}
                    <span class="input-group-addon icomoon-uniE04B" style="font-size:large;"></span>
                </div>
            </div>
        </div>
        <div class="col-md-3 pull-right right">
            <div class="form-group">
                <label for="inputEmail">راننده</label>
                <div class="input-group">
                    {!!Form::text("driver", null, array("class"=>'form-control autosizeme', "style"=>"height:40px;", "placeholder"=>"..."))!!}
                    <span class="input-group-addon icomoon-uniE04B" style="font-size:large;"></span>
                </div>
            </div>
        </div>
        <div class="col-md-3 pull-right right">
            <div class="form-group">
                <label for="inputEmail">تاریخ صدور فاکتور</label>
                <div class="input-group">
                    {!!Form::text("issue_date", null, array("class"=>'form-control autosizeme', "style"=>"height:40px;", "placeholder"=>"..."))!!}
                    <span class="input-group-addon icomoon-uniE04B" style="font-size:large;"></span>
                </div>
            </div>
        </div>
        <div class="col-md-3 pull-right right">
            <div class="form-group">
                <label for="inputEmail">نوع خریدار</label>
                <div class="input-group">
                    {!!Form::select("buyer_type", $buyer_type, null, array("class"=>'form-control autosizeme', "style"=>"height:40px;"))!!}
                    <span class="input-group-addon icomoon-uniE04B" style="font-size:large;"></span>
                </div>
            </div>
        </div>
        <div class="col-md-3 pull-right right">
            <div class="form-group">
                <label for="inputEmail">شماره پیوست</label>
                <div class="input-group">
                    {!!Form::text("attachment_id", null, array("class"=>'form-control autosizeme', "style"=>"height:40px;"))!!}
                    <span class="input-group-addon icomoon-uniE04B" style="font-size:large;"></span>
                </div>
            </div>
        </div>
        <div class="col-md-3 pull-right right">
            <div class="form-group">
                <label for="inputEmail">منطقه</label>
                <div class="input-group">
                    {!!Form::select("zone", $zone ,null , array("class"=>'form-control autosizeme', "style"=>"height:40px;"))!!}
                    <span class="input-group-addon icomoon-uniE04B" style="font-size:large;"></span>
                </div>
            </div>
        </div>
        <div class="col-md-3 pull-right right">
            <div class="form-group">
                <label for="inputEmail">امضاء کننده قرارداد</label>
                <div class="input-group">
                    {!!Form::select("signer", $signer, null, array("class"=>'form-control autosizeme', "style"=>"height:40px;"))!!}
                    <span class="input-group-addon icomoon-uniE04B" style="font-size:large;"></span>
                </div>
            </div>
        </div>
        <div class="col-md-3 pull-right right">
            <div class="form-group">
                <label for="inputEmail">توضحیات</label>
                <div class="input-group">
                    {!!Form::text("comment", null, array("class"=>'form-control autosizeme', "style"=>"height:40px;"))!!}
                    <span class="input-group-addon icomoon-uniE04B" style="font-size:large;"></span>
                </div>
            </div>
        </div>
    </div>
    <hr>
    <div class="row">
        <div class="col-md-12 col-sm-12 col-lg-12">
            <input type="submit" value="ذخیره" class="btn btn-primary"/>
        </div>
    </div>
    {!! Form::close() !!}
</div>
@endsection

@section("script")
    {!! Html::script("invoice-create.js") !!}
@endsection