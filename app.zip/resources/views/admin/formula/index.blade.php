@extends("admin.master")
@section("content")
    {!! Breadcrumbs::render('user.index') !!}
    <div class="wrapper" id="wrapper">
        <div class="row">
            <div class="col-md-12">
                {{ !empty(Session::get('msg'))? message(Session::get('msg')):"" }}
                {{errors($errors)}}
                <datagridview :head="head" :url="url"></datagridview>
            </div>
        </div>
    </div>
@endsection

@section("script")


    <script>

        var data = {
            url: "{{action('FormulaController@getIndex')}}",
            head: {
                fake_id  : "#",
                code:    'کد',
                created_date:  'تاریخ تولید',
                concentrate_type:   'نوع کنسانتره',
                protein:    'پروتئین',
                pure_lactation_energy:     'انرژی خالص شیر دهی',
                metabolism_energy:  'متابولیسم',
                dry_matter:  'ماده خشک',
                calcium:  'کلسیم',
                phosphorus: 'فسفر',
                product_name: 'نام محصول'
            },
            buttons:{
                edit:{
                    label: "ویرایش",
                    btnClass: "btn btn-warning",
                    url: "{{action('FormulaController@getIndex')}}/edit/{id}",
                    action: 'without-confirm',
                    style: "font-size:smaller;margin-left:10px;"
                },
                showItems:{
                    label: 'اقلام',
                    btnClass: "btn btn-primary",
                    url: "{{action('FormulaController@getIndex')}}/items/{id}",
                    action: 'without-confirm',
                    style: "font-size:smaller;margin-left:10px;"
                },
                createItems:{
                    label: 'ایجاد قلم',
                    btnClass: "btn btn-primary",
                    url: "{{action('FormulaController@getIndex')}}/item/create/{id}",
                    action: 'without-confirm',
                    style: "font-size:smaller;margin-left:10px;"
                },
                removeInvoice:{
                    label: 'حذف فرمول',
                    btnClass: "btn btn-danger",
                    url: "{{action('FormulaController@getIndex')}}/delete/{id}",
                    action: 'confirm',
                    confirm_text: 'از حذف این رکورد مطمئن هستید ؟',
                    style: "font-size:smaller;margin-left:10px;"
                }
            }
        }

    </script>

    {!! Html::script("invoice-index.js") !!}
@endsection