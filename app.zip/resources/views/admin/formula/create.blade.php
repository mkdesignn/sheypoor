@extends("admin.master")
@section("content")
    {!! Breadcrumbs::render('user.index') !!}
    <div class="wrapper" id="wrapper">
        {{ !empty(Session::get('msg'))? message(Session::get('msg')):"" }}
        {{errors($errors)}}
        {!! Form::open(["url"=>url()->action("FormulaController@postStore")]) !!}
        <div class="row" style="overflow:auto;margin-bottom:20px;">
            <div class="col-md-12 col-lg-12 col-sm-12">
                <h4>
                    اطلاعات اولیه
                </h4>
            </div>
            <div class="col-md-3 pull-right right">
                <div class="form-group">
                    <label for="inputEmail">کد فرمول</label>
                    <div class="input-group">
                        {!!Form::text("code", null, array("class"=>'form-control autosizeme',
                         "v-bind:class"=>"{'border-danger': errors.has('code')}", "v-validate"=>"'required'", "style"=>"height:40px;", "placeholder"=>"..."))!!}
                        <span class="input-group-addon icomoon-uniE04B" style="font-size:large;"></span>
                    </div>
                </div>
            </div>
            <div class="col-md-3 pull-right right">
                <div class="form-group">
                    <label for="inputEmail">تاریخ تولید</label>
                    <div class="input-group">
                        <date-picker name="created_date" v-on:change="getDate" v-model="myDate" v-bind:class="{'border-danger': errors.has('created_date')}"
                                     v-validate="'required'" :option="option" style="height:40px;width:100%;"></date-picker>
                        <input type="hidden" name="created_date" v-model="date"/>
                        {{--{!!Form::text("created_date", null, array("class"=>'form-control autosizeme', "tabindex"=>"0",--}}
                         {{--"v-bind:class"=>"{'border-danger': errors.has('created_date')}", "v-validate"=>"'required'", "style"=>"height:40px;", "placeholder"=>"..."))!!}--}}
                        <span class="input-group-addon icomoon-uniE04B" style="font-size:large;"></span>
                    </div>
                </div>
            </div>
            <div class="col-md-3 pull-right right">
                <div class="form-group">
                    <label for="inputEmail">نوع کنسانتره</label>
                    <div class="input-group">
                        {!!Form::select("concentrate_type", $concentrate_type, null, array("class"=>'form-control autosizeme', "style"=>"height:40px;",
                         "v-bind:class"=>"{'border-danger': errors.has('concentrate_type')}", "v-validate"=>"'required'", "placeholder"=>"..."))!!}
                        <span class="input-group-addon icomoon-uniE04B" style="font-size:large;"></span>
                    </div>
                </div>
            </div>
            <div class="col-md-3 pull-right right">
                <div class="form-group">
                    <label for="inputEmail">پروتئین</label>
                    <div class="input-group">
                        {!!Form::text("protein", null, array("class"=>'form-control autosizeme', "style"=>"height:40px;",
                         "v-bind:class"=>"{'border-danger': errors.has('protein')}", "v-validate"=>"'required'", "placeholder"=>"..."))!!}
                        <span class="input-group-addon icomoon-uniE04B" style="font-size:large;"></span>
                    </div>
                </div>
            </div>
            <div class="col-md-3 pull-right right">
                <div class="form-group">
                    <label for="inputEmail">انرژی خالص شیردهی</label>
                    <div class="input-group">
                        {!!Form::text("pure_lactation_energy", null, array("class"=>'form-control autosizeme',
                         "v-bind:class"=>"{'border-danger': errors.has('pure_lactation_energy')}", "v-validate"=>"'required'", "style"=>"height:40px;"))!!}
                        <span class="input-group-addon icomoon-uniE04B" style="font-size:large;"></span>
                    </div>
                </div>
            </div>
            <div class="col-md-3 pull-right right">
                <div class="form-group">
                    <label for="inputEmail">متابولیسم</label>
                    <div class="input-group">
                        {!!Form::text("metabolism_energy", null, array("class"=>'form-control autosizeme',
                         "v-bind:class"=>"{'border-danger': errors.has('metabolism_energy')}", "v-validate"=>"'required'", "style"=>"height:40px;"))!!}
                        <span class="input-group-addon icomoon-uniE04B" style="font-size:large;"></span>
                    </div>
                </div>
            </div>
            <div class="col-md-3 pull-right right">
                <div class="form-group">
                    <label for="inputEmail">ماده خشک</label>
                    <div class="input-group">
                        {!!Form::text("dry_matter",null , array("class"=>'form-control autosizeme',
                         "v-bind:class"=>"{'border-danger': errors.has('dry_matter')}", "v-validate"=>"'required'", "style"=>"height:40px;"))!!}
                        <span class="input-group-addon icomoon-uniE04B" style="font-size:large;"></span>
                    </div>
                </div>
            </div>
            <div class="col-md-3 pull-right right">
                <div class="form-group">
                    <label for="inputEmail">کلسیم</label>
                    <div class="input-group">
                        {!!Form::text("calcium", null, array("class"=>'form-control autosizeme',
                         "v-bind:class"=>"{'border-danger': errors.has('calcium')}", "v-validate"=>"'required'", "style"=>"height:40px;"))!!}
                        <span class="input-group-addon icomoon-uniE04B" style="font-size:large;"></span>
                    </div>
                </div>
            </div>
            <div class="col-md-3 pull-right right">
                <div class="form-group">
                    <label for="inputEmail">فسفر</label>
                    <div class="input-group">
                        {!!Form::text("phosphorus", null, array("class"=>'form-control autosizeme', "style"=>"height:40px;"))!!}
                        <span class="input-group-addon icomoon-uniE04B" style="font-size:large;"></span>
                    </div>
                </div>
            </div>
            <div class="col-md-3 pull-right right">
                <div class="form-group">
                    <label for="inputEmail">نام محصول</label>
                    <div class="input-group">
                        {!!Form::select("product_name", $concentrate_type, null, array("class"=>'form-control autosizeme', "style"=>"height:40px;"))!!}
                        <span class="input-group-addon icomoon-uniE04B" style="font-size:large;"></span>
                    </div>
                </div>
            </div>
        </div>
        <hr>
        <div class="row">
            <div class="col-md-12 col-sm-12 col-lg-12">
                <input type="submit" v-on:click="submitForm" value="ذخیره" class="btn btn-primary"/>
            </div>
        </div>
        {!! Form::close() !!}
    </div>
@endsection

@section("script")

    <script>
        var data = {
            date: {
                time: '1396-05-05'
            },
            myDate: new Date(), // for v-model
            startTime: {
                time: '' // '1396-05-02' (type=day) && '["1396/05/02", "1396/06/02", "1396/07/02"]' (type="multi-day")
            },
            option: {
                type: 'day',
                week: ['شنبه', 'یکشنبه', 'دوشنبه', 'سه شنبه', 'چهارشنبه', 'پنجشنبه', 'جمعه'],
                month: ['فروردین', 'اردیبهشت', 'خرداد', 'تیر', 'مرداد', 'شهریور', 'مهر', 'آبان', 'آذر', 'دی', 'بهمن', 'اسفند'],
                format: 'jYYYY-jMM-jDD',
                placeholder: 'انتخاب کنید',
                inputStyle: {
                    'display': 'inline-block',
                    'padding': '8px',
                    'line-height': '22px',
                    'font-size': '16px',
                    'border': '1px solid #ccc',
                    'box-shadow': 'none',
                    'border-radius': '2px',
                    'color': '#5F5F5F',
                    'width': '100%'
                },
                color: {
                    header: '#ccc',
                    headerText: '#f00'
                },
                buttons: {
                    ok: 'انتخاب',
                    cancel: 'انصراف'
                },
                overlayOpacity: 0.5, // 0.5 as default
                dismissible: true // as true as default
            }
        }
    </script>


    {!! Html::script("formula-create.js") !!}
@endsection