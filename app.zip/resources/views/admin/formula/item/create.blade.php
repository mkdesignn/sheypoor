@extends("admin.master")
@section("content")
    {!! Breadcrumbs::render('user.index') !!}
    <div class="wrapper" id="wrapper">
        {{ !empty(Session::get('msg'))? message(Session::get('msg')):"" }}
        {{errors($errors)}}
        {!! Form::open(["url"=>url()->action("FormulaController@postStoreItem", $formula_id)]) !!}
        <div class="row" style="overflow:auto;margin-bottom:20px;">
            <div class="col-md-12 col-lg-12 col-sm-12">
                <h4>
                    اطلاعات اولیه
                </h4>
            </div>
            <div class="col-md-3 pull-right right">
                <div class="form-group">
                    <label for="inputEmail">نام</label>
                    <div class="input-group">
                        {!!Form::text("item_name", null, array("class"=>'form-control autosizeme', "v-bind:class"=>"{'border-danger': errors.has('code')}",
                         "v-validate"=>"'required'", 'v-model'=>"name", "style"=>"height:40px;", "placeholder"=>"..."))!!}
                        <span class="input-group-addon icomoon-uniE04B" style="font-size:large;"></span>
                    </div>
                </div>
            </div>
            <div class="col-md-3 pull-right right">
                <div class="form-group">
                    <label for="inputEmail">درصد استفاده</label>
                    <div class="input-group">
                        {!!Form::text("item_percent", null, array("class"=>'form-control autosizeme', 'v-model'=>"percentage",
                        "v-bind:class"=>"{'border-danger': errors.has('code')}", "v-validate"=>"'required'", "style"=>"height:40px;", "placeholder"=>"..."))!!}
                        <span class="input-group-addon icomoon-uniE04B" style="font-size:large;"></span>
                    </div>
                </div>
            </div>
        </div>
        <hr>
        <div class="row">
            <div class="col-md-12 col-sm-12 col-lg-12">
                <input type="submit" v-on:click="submitForm" value="ذخیره" class="btn btn-primary"/>
            </div>
        </div>
        {!! Form::close() !!}
    </div>
@endsection

@section("script")

    <script>

        var data = {
            name: '',
            percentage : ''
        }

    </script>

    {!! Html::script("create-item.js") !!}
@endsection