{!! Html::script("vendor-css.js") !!}
<style>
    p{
        margin:5px;
    }

    table{
        border-collapse: collapse;
        direction:rtl;
        width:100%;
    }

    table td{
        text-align:center;
        padding:5px;
        /*font-size:smaller;*/
    }

    @media print {
        .page-break	{ display: block; page-break-before: always; }
    }
</style>
@foreach( $articles as $article )
    <div style="width:90%;text-align:center;margin:auto;padding-top:40px;">
        <p style="text-align:center;font-size:larger"> شرکت خوراک دام و طیور اهواز </p>
        <p style="text-align:left;padding-top:20px;"> تاریخ فاکتور : {{$invoice->issue_date}} </p>
        <p style="text-align:left;padding-top:20px;"> شماره پیوست :  {{$invoice->attachment_id}}</p>
        <table border="1">
            <tr>
                <td>سفارش : {{$invoice->buyer}}</td>
                <td>نوع کنسانتره: {{$article->formula->concentrate->meta_value}}</td>
                <td>تاریخ تولید: {{$article->formula->created_date}}</td>
                <td>کد فرمول: {{$article->formula->code}}</td>
            </tr>
            <tr>
                <td>اقلام</td>
                <td>درصد</td>
                <td colspan="2">میزان مصرف</td>
            </tr>
            @foreach($article->formula->items as $formula_item)
                <tr>
                    <td>{{$formula_item->item_name}}</td>
                    <td>{{$formula_item->item_percent}}</td>
                    <td colspan="2">{{ ceil( ($article->total_weight * $formula_item->item_percent) / 100 ) }}</td>
                </tr>
            @endforeach
            <tr>
                <td></td>
                <td>100</td>
                <td colspan="2">{{$article->total_weight}}</td>
            </tr>
        </table>
    </div>
    <div class="page-break"></div>
@endforeach