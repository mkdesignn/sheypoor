{!! Html::script("vendor-css.js") !!}
<style>
    p{
        margin:5px;
    }

    table{
        border-collapse: collapse;
        direction:rtl;
        width:100%;
    }

    table td{
        text-align:center;
        padding:5px;
        /*font-size:smaller;*/
    }

    @media print {
        .page-break	{ display: block; page-break-before: always; }
    }
</style>

<div style="width:90%;text-align:center;margin:auto;padding-top:40px;">
    <p style="text-align:center;font-size:larger"> شرکت خوراک دام و طیور اهواز </p>
    <p style="text-align:left;padding-top:20px;"> تاریخ فاکتور : {{$invoice->issue_date}} </p>
    <p style="text-align:left;padding-top:20px;"> شماره پیوست :  {{$invoice->attachment_id}}</p>
    <table border="1">
        <tr>
            <td>نماینده انحصاری</td>
            <td>منطقه</td>
            <td>درصد پورسانت</td>
            <td>هزینه پورسانت</td>
        </tr>
        <tr>
            <td>{{$invoice->agency->agency_name}}</td>
            <td>{{$invoice->agency->zone}}</td>
            <td>{{$invoice->agency->discount_percent}}</td>
            <td>{{ number_format( ( $invoice->price * $invoice->agency->discount_percent) / 100 ) }}</td>
        </tr>
        <tr>
            <td colspan="2">نماینده رسمی: {{$invoice->buyer}}</td>
            <td colspan="2">مبلغ کل فاکتور: {{ number_format( $invoice->price ) }}</td>
        </tr>
    </table>
</div>