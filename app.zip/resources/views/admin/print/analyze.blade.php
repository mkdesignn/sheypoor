{!! Html::script("vendor-css.js") !!}
<style>
    p{
        margin:5px;
    }

    table{
        border-collapse: collapse;
        direction:rtl;
        width:100%;
    }

    table td{
        text-align:center;
        padding:5px;
        /*font-size:smaller;*/
    }

    @media print {
        .page-break	{ display: block; page-break-before: always; }
    }
</style>
@foreach( $articles as $article )
    <div style="width:90%;text-align:center;margin:auto;padding-top:40px;">
        <p style="text-align:center;font-size:larger"> شرکت خوراک دام و طیور اهواز </p>
        <p style="text-align:left;padding-top:20px;"> تاریخ فاکتور : {{$invoice->issue_date}} </p>
        <p style="text-align:left;padding-top:20px;"> شماره پیوست :  {{$invoice->attachment_id}}</p>
        <table border="1">
            <tr>
                <td>سفارش آقای : {{$invoice->buyer}}</td>
                <td colspan="2">نوع کنسانتره: {{$article->formula->concentrate->meta_value}}</td>
                <td>تاریخ تولید: {{$article->formula->created_date}}</td>
                <td colspan="2">کد فرمول: {{$article->formula->code}}</td>
            </tr>
            <tr>
                <td colspan="6">آنالیز فرمول</td>
            </tr>
            <tr>
                <td>پروتئین</td>
                <td>انرژی خالص شیر دهی</td>
                <td>انرژی خالص متابولیسم</td>
                <td>ماده خشک</td>
                <td>کلسیم</td>
                <td>فسفر</td>
            </tr>
            <tr>
                <td>{{$article->formula->protein}}</td>
                <td>{{$article->formula->pure_lactation_energy}}</td>
                <td>{{$article->formula->metabolism_energy}}</td>
                <td>{{$article->formula->dry_matter}}</td>
                <td>{{$article->formula->calcium}}</td>
                <td>{{$article->formula->phosphorus}}</td>
            </tr>
        </table>
        <p style="padding-top:30px;">ترکیبات : {{ implode($article->formula->items->pluck("item_name")->toArray(), " , ")  }} </p>
        <p style="padding-top:20px;"></p>
        <p style="padding-top:10px"> ارتباط با ما </p>
        <p style="padding-top:20px"> مشاور تغذیه دام و طیور : دکتر علیرضا جولا زاده 09165942218 </p>
        <p style="padding-top:10px"> مشاور دامپزشکی : دکتر فاطمه عباسی هرمزی 09120710856 </p>
    </div>
    <div class="page-break"></div>
@endforeach