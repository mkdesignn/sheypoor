{!! Html::script("vendor-css.js") !!}
<style>
    td, th{
        text-align:center;
    }

    td.rotate {
        /* Something you can count on */
        height: 140px;
        white-space: nowrap;
    }

    td.rotate > div {
        transform: translate(-7px, -30px) rotate(270deg);
        width: 18px;
    }

    td.id > div{
        transform: translate(-15px, -20px) rotate(268deg) !important;
    }

    td.price > div{
        transform: translate(-7px, -18px) rotate(270deg) !important;
    }

    td.price > div{
        transform: translate(-14px, -41px) rotate(270deg) !important;
    }

    td.code > div{
        transform: translate(-14px, -36px) rotate(270deg) !important;
    }

    td.weight > div{
        transform: translate(-7px, -31px) rotate(269deg) !important;
    }

    td.bag > div{
        transform: translate(-14px, -31px) rotate(267deg) !important;
    }

    td.rotate > div > span {
        padding: 5px 10px;
    }

    td.rotate > div{
        transform: translate(-14px, -58px) rotate(270deg);
    }

    td.total_price > div{
        transform: translate(-14px, -19px) rotate(270deg);
    }

    .border_bottom{
        border-bottom:1px solid rgba(42,42,42,.3);
    }

    .border_right{
        border-right:1px solid rgba(42,42,42,.3);
    }

    .padding_bottom_top{
        padding-top:10px;
        padding-bottom:10px;
    }

</style>
<div class="first_invoice" style="width:90%;margin:auto;padding-top: 8em;">
    <p>
        <span style="float:right">خریدار : {{$invoice->buyer}}</span>
        <span style="float:left;">تاریخ: {{$invoice->issue_date}}</span>
    </p>
    <table border="1" style="clear: both;width: 100%;border-collapse: collapse;direction: rtl;">
        <thead>
            <td class="rotate id"><div><span>ردیف</span></div></td>
            <td >شرح کالا</td>
            <td class="rotate code"><div><span>کد فرمول</span></div></td>
            <td class="rotate bag"><div><span>تعداد کیسه</span></div></td>
            <td class="rotate weight"><div><span>وزن کالا</span></div></td>
            <td class="rotate price"><div><span>قیمت واحد</span></div></td>
            <td style="height:100%;padding:0px;width:34%;">
                <table style="width:100%;border-collapse: collapse">
                    <thead>
                    <tr>
                        <td class="border_bottom padding_bottom_top">شرایط فروش</td>
                    </tr>
                    <tr>
                        <td>
                            <table style="width:100%;border-collapse: collapse">
                                <thead>
                                <td>
                                    <table style="width:100%;border-collapse: collapse">
                                        <thead>
                                        <tr>
                                            <td class="border_bottom padding_bottom_top">نقدی</td>
                                        </tr>
                                        <tr>
                                            <td class="padding_bottom_top">درصد تخفیف</td>
                                        </tr>
                                        </thead>
                                    </table>
                                </td>
                                <td class="border_right">
                                    <table style="width:100%;border-collapse: collapse">
                                        <thead>
                                        <tr>
                                            <td class="border_bottom padding_bottom_top">مدت دار</td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <table style="width:100%;border-collapse: collapse">
                                                    <thead>
                                                    <tr>
                                                        <td class="padding_bottom_top">درصد</td>
                                                        <td class="padding_bottom_top border_right">زمان</td>
                                                    </tr>
                                                    </thead>
                                                </table>
                                            </td>
                                        </tr>
                                        </thead>
                                    </table>
                                </td>
                                <td class="border_right padding_bottom_top">
                                    مدت تنفس
                                </td>
                                </thead>
                            </table>
                        </td>
                    </tr>
                    </thead>
                </table>
            </td>
            <td class="rotate final_price">
                <div><span>قیمت تمام شده</span></div>
            </td>
            <td class="rotate total_price">
                <div><span>مبلغ</span></div>
            </td>
            <td class="rotate date">
                <div><span>تاریخ تسویه حساب</span></div>
            </td>
        </thead>
        <tbody>
            <?php $sum = 0; $appended = 0; $decendend = 0; $total_price = 0; $total_weight = 0;?>
            @foreach($articles as $key => $article)
                <tr>
                    <td>{{$key + 1}}</td>
                    <td>{{$article->comment}}</td>
                    <td>{{$article->formula->code}}</td>
                    <td>{{number_format($article->total_bag)}}</td>
                    <td>{{number_format($article->total_weight)}}</td>
                    <td>{{number_format($article->price)}}</td>
                    <td>
                        <table style="width:100%;">
                            <tr>
                                <td style="width:38%">{{$article->discount_price_percent}}</td>
                                <td style="width:16.2%;" class="border_right">{{$article->profit_percent}}</td>
                                <td style="width:13.6%;" class="border_right">{{$article->time}}</td>
                                <td class="border_right">{{$article->breath_time}}</td>
                            </tr>
                        </table>
                    </td>
                    <td>{{number_format($article->finish_price)}}</td>
                    <td>
                        <?php
                            $sum += $article->price * $article->total_weight;

                            $appended += ( ( $article->total_weight * $article->price ) < ( $article->total_weight * $article->finish_price ) ) ? ($article->finish_price - $article->price) * $article->total_weight : 0;
                            $decendend += ( ( $article->total_weight * $article->finish_price ) < ( $article->total_weight * $article->price ) ) ? ($article->price - $article->finish_price) * $article->total_weight : 0;
                            echo number_format($article->total_weight * $article->finish_price);
                            $total_price += $article->total_weight * $article->finish_price;
                        ?>
                    </td>
                    <td><?php $date = invoiceArticleTime($article->time); echo $date[0]."/".$date[1]."/".$date[2]; ?></td>
                </tr>
            @endforeach
            <tr>
                <td colspan="6"></td>
                <td> جمع کل فاکتور قبل از تغییرات </td>
                <td colspan="3">
                    {{number_format($sum)}}
                </td>
            </tr>
            <tr>
                <td colspan="6"></td>
                <td> جمع تخفیفات فروش </td>
                <td>-</td>
                <td colspan="2">
                    {{number_format($decendend)}}
                </td>
            </tr>
            <tr>
                <td colspan="6"> نوع خریدار : {{$invoice->buyer_type}} </td>
                <td> جمع اضافات بدهی مدت دار </td>
                <td>+</td>
                <td colspan="2">
                    {{number_format($appended)}}
                </td>
            </tr>
            <tr>
                <td colspan="3">تعداد کل کیسه : {{$articles->sum('total_bag')}} </td>
                <td colspan="3"> وزن کل : {{ $total_weight = $articles->sum("total_weight")}} </td>
                <td> جمع کل مبلغ </td>
                <td colspan="3">
                    {{number_format($total_price)}}
                </td>
            </tr>
        </tbody>
    </table>
    <div>
        <p style="padding-top:10px;">
            <?php settype($total_price, "integer"); ?>
            مبلغ کل به حروف : {{translateToWords( $total_price )}}
        </p>
        <p>
            <span style="float:right">راننده :{{ $invoice->driver }}</span>
            <span style="float:left">امضاء مسئول فروش: {{ $invoice->singers->meta_value }}</span>
        </p>
        <br>
        <p style="clear:both;padding-top:10px;">
            خریدار محترم در صورت هر گونه
            مغایرت در کیفیت و قیمت گذاری کالای خریداری شده حداکثر 24 ساعت جهت اطلاع رسانی برای تعویض کالا یا تغییر قیمت فاکتور خود مهلت دارید در غیر اینصورت شرکت هیچ گونه
            مسئولیتی را عهده دار نخواهد بود . )
        </p>
    </div>
</div>
<div class="middle_note" style="width:90%;margin:auto;padding-top: 20em;">
    <p style="text-align:left;">
        {{$invoice->issue_date}}
    </p>
    <p>
        {{$invoice->buyer}} مقدار {{$total_weight}} کیلو گرم به مبلغ {{translateToWords( $total_price )}} ریال را از شرکت خوارک دام و طیور اهواز توسط آقای {{$invoice->driver}} به شماره ماشین {{$invoice->car_number}} تحویل گرفته است .
    </p>
    <p style="text-align:left;">
        نام و امضای خریدار
    </p>
</div>
<div class="last_invoice" style="width:90%;margin:auto;padding-top: 10em;">
    <p>
        <span style="float:right">خریدار : {{$invoice->buyer}}</span>
        <span style="float:left;">تاریخ: {{$invoice->issue_date}}</span>
    </p>
    <table border="1" style="clear: both;width: 100%;border-collapse: collapse;direction: rtl;">
        <thead>
        <td class="rotate id"><div><span>ردیف</span></div></td>
        <td >شرح کالا</td>
        <td class="rotate code"><div><span>کد فرمول</span></div></td>
        <td class="rotate bag"><div><span>تعداد کیسه</span></div></td>
        <td class="rotate weight"><div><span>وزن کالا</span></div></td>
        <td class="rotate price"><div><span>قیمت واحد</span></div></td>
        <td style="height:100%;padding:0px;width:34%;">
            <table style="width:100%;border-collapse: collapse">
                <thead>
                <tr>
                    <td class="border_bottom padding_bottom_top">شرایط فروش</td>
                </tr>
                <tr>
                    <td>
                        <table style="width:100%;border-collapse: collapse">
                            <thead>
                            <td>
                                <table style="width:100%;border-collapse: collapse">
                                    <thead>
                                    <tr>
                                        <td class="border_bottom padding_bottom_top">نقدی</td>
                                    </tr>
                                    <tr>
                                        <td class="padding_bottom_top">درصد تخفیف</td>
                                    </tr>
                                    </thead>
                                </table>
                            </td>
                            <td class="border_right">
                                <table style="width:100%;border-collapse: collapse">
                                    <thead>
                                    <tr>
                                        <td class="border_bottom padding_bottom_top">مدت دار</td>
                                    </tr>
                                    <tr>
                                        <td>
                                            <table style="width:100%;border-collapse: collapse">
                                                <thead>
                                                <tr>
                                                    <td class="padding_bottom_top">درصد</td>
                                                    <td class="padding_bottom_top border_right">زمان</td>
                                                </tr>
                                                </thead>
                                            </table>
                                        </td>
                                    </tr>
                                    </thead>
                                </table>
                            </td>
                            <td class="border_right padding_bottom_top">
                                مدت تنفس
                            </td>
                            </thead>
                        </table>
                    </td>
                </tr>
                </thead>
            </table>
        </td>
        <td class="rotate final_price">
            <div><span>قیمت تمام شده</span></div>
        </td>
        <td class="rotate total_price">
            <div><span>مبلغ</span></div>
        </td>
        <td class="rotate date">
            <div><span>تاریخ تسویه حساب</span></div>
        </td>
        </thead>
        <tbody>
        <?php $sum = 0; $appended = 0; $decendend = 0; $total_price = 0;?>
        @foreach($articles as $key => $article)
            <tr>
                <td>{{$key + 1}}</td>
                <td>{{$article->comment}}</td>
                <td>{{$article->formula->name}}</td>
                <td>{{number_format($article->total_bag)}}</td>
                <td>{{number_format($article->total_weight)}}</td>
                <td>{{number_format($article->price)}}</td>
                <td>
                    <table style="width:100%;">
                        <tr>
                            <td style="width:38%">{{$article->discount_price_percent}}</td>
                            <td style="width:16.2%;" class="border_right">{{$article->profit_percent}}</td>
                            <td style="width:13.6%;" class="border_right">{{$article->time}}</td>
                            <td class="border_right">{{$article->breath_time}}</td>
                        </tr>
                    </table>
                </td>
                <td>{{number_format($article->finish_price)}}</td>
                <td>
                    <?php
                    $sum += $article->price * $article->total_weight;

                    $appended += ( ( $article->total_weight * $article->price ) < ( $article->total_weight * $article->finish_price ) ) ? ($article->finish_price - $article->price) * $article->total_weight : 0;
                    $decendend += ( ( $article->total_weight * $article->finish_price ) < ( $article->total_weight * $article->price ) ) ? ($article->price - $article->finish_price) * $article->total_weight : 0;
                    echo number_format($article->total_weight * $article->finish_price);
                    $total_price += $article->total_weight * $article->finish_price;
                    ?>
                </td>
                <td><?php $date = invoiceArticleTime($article->time); echo $date[0]."/".$date[1]."/".$date[2]; ?></td>
            </tr>
        @endforeach
        <tr>
            <td colspan="6"></td>
            <td> جمع کل فاکتور قبل از تغییرات </td>
            <td colspan="3">
                {{number_format($sum)}}
            </td>
        </tr>
        <tr>
            <td colspan="6"></td>
            <td> جمع تخفیفات فروش </td>
            <td>-</td>
            <td colspan="2">
                {{number_format($decendend)}}
            </td>
        </tr>
        <tr>
            <td colspan="6"> نوع خریدار : {{$invoice->buyer_type}} </td>
            <td> جمع اضافات بدهی مدت دار </td>
            <td>+</td>
            <td colspan="2">
                {{number_format($appended)}}
            </td>
        </tr>
        <tr>
            <td colspan="3">تعداد کل کیسه : {{$articles->sum('total_bag')}} </td>
            <td colspan="3"> وزن کل : {{$articles->sum("total_weight")}} </td>
            <td> جمع کل مبلغ </td>
            <td colspan="3">
                {{number_format($total_price)}}
            </td>
        </tr>
        </tbody>
    </table>
    <div>
        <p style="padding-top:10px;">
            <?php settype($total_price, "integer"); ?>
            مبلغ کل به حروف : {{translateToWords( $total_price )}}
        </p>
        <p>
            <span style="float:right">راننده :{{ $invoice->driver }}</span>
            <span style="float:left">امضاء مسئول فروش: {{ $invoice->singers->meta_value }}</span>
        </p>
        <br>
        <p style="clear:both;padding-top:10px;">
          توضیحات :{{$invoice->comment}}
        </p>
    </div>
</div>

