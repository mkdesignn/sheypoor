import axios from 'axios';
import Vue from 'vue';

require('../../../node_modules/vue/dist/vue.js');
require('../../../node_modules/amcharts3/amcharts/amcharts.js');
require('../../../node_modules/amcharts3/amcharts/serial.js');
window.Vue = require('vue');
global.jQuery = require('jquery');

require("./ease.js");
require("./ease2.js");
require('./index.js');
require("../../../node_modules/bootstrap3/dist/js/bootstrap.min.js");
