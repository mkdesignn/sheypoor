import Vue from 'vue';
import datagridview from './../components/datagrid.vue';
Vue.component("datagridview", datagridview);

var app = new Vue({
    el: '#wrapper',
    data: data
});
