<?php $__env->startSection("content"); ?>
    <?php echo Breadcrumbs::render('user.create'); ?>

    <?php echo $__env->make("admin.users.form", ["action"=>action('UserController@postStore'),
    "user"=>[], "button"=>"ذخیره", "id"=>""], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("admin.master", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>