<?php $__env->startSection("content"); ?>
    <?php echo Breadcrumbs::render('user.index'); ?>

    <div class="wrapper" id="wrapper">
        <div class="row">
            <div class="col-md-12">
                <?php echo e(!empty(Session::get('msg'))? message(Session::get('msg')):""); ?>

                <?php echo e(errors($errors)); ?>

                <datagridview :head="head" :url="url"></datagridview>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection("script"); ?>


    <script>

        var data = {
            url: "<?php echo e(action('InvoiceController@getIndex')); ?>",
            head: {
                fake_id  : "#",
                buyer:    'خریدار',
                car_number:  'شماره ماشین',
                driver:   'راننده',
                issue_date:    'تاریخ صدو فاکتور',
                buyer_type:     'نوع خریدار',
                attachment_id:  'شماره پیوست',
                'agency.zone':  'منطقه',
                'singers.meta_value':  'امضاء کننده'
            },
            buttons:{
                edit:{
                    label: "ویرایش",
                    btnClass: "btn btn-warning",
                    url: "<?php echo e(action('InvoiceController@getIndex')); ?>/edit/{id}",
                    action: 'without-confirm',
                    style: "font-size:smaller;margin-left:10px;"
                },
                showArticles:{
                    label: 'قلم فاکتور',
                    btnClass: "btn btn-primary",
                    url: "<?php echo e(action('InvoiceController@getIndex')); ?>/articles/{id}",
                    action: 'without-confirm',
                    style: "font-size:smaller;margin-left:10px;"
                },
                removeInvoice:{
                    label: 'حذف فاکتور',
                    btnClass: "btn btn-danger",
                    url: "<?php echo e(action('InvoiceController@getIndex')); ?>/delete/{id}",
                    action: 'confirm',
                    confirm_text: 'از حذف این رکورد مطمئن هستید ؟',
                    style: "font-size:smaller;margin-left:10px;"
                }
            }
        }

    </script>

    <?php echo Html::script("invoice-index.js"); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make("admin.master", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>