<?php $__env->startSection("header"); ?>
    <title>صفحه مورد نظر یافت نشد</title>
<?php $__env->stopSection(); ?>
<?php $__env->startSection("content"); ?>
    <main class="container content-wrap">
        <!-- col-lg-9 col-md-9 col-sm-8 -->
        <section class="blog-posts">
           <h3 class="center"> صفحه مورد نظر یافت نشد  </h3>
        </section>
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("master", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>